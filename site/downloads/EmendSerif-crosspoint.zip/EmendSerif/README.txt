EmendSerif -- a reading font for CrossPoint e-readers (Xteink X3, X4)
from Emend Press, https://emend.press/about.html

The built-in fonts on these readers have no logic or mathematics signs, so
books like Gödel's Proof or Boole's Laws of Thought show boxes where the
symbols should be. This font has every character used in the Emend Press
books.

To install: copy the EmendSerif folder into the /fonts/ folder on the reader's
SD card (make the folder if it is not there), then choose EmendSerif as the
reading font in the reader's settings. Sizes 12, 14, 16 and 18.

Made from Literata (The Literata Project Authors), with Noto Serif, Noto
Sans Math, Noto Sans Symbols, Noto Sans Symbols 2, Noto Sans Runic and
Noto Music (Google LLC) for the characters Literata lacks. Converted with
CrossPoint's own font tool. Licensed under the SIL Open Font License 1.1;
see OFL.txt.
